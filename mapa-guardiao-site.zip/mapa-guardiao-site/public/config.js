// Preencha estes dois valores com os do seu projeto no Supabase (Project Settings > API).
// Os dois são PÚBLICOS por natureza: pode deixá-los aqui. A chave da IA do Claude NÃO vai aqui (fica na Vercel).
window.APP_CONFIG = {
  SUPABASE_URL: '',        // ex.: https://abcdefgh.supabase.co
  SUPABASE_ANON_KEY: '',   // chave "anon public"
  ADMIN_EMAIL: 'contato.energystudio@gmail.com'
};
