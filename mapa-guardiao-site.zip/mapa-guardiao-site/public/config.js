// Preencha estes dois valores com os do seu projeto no Supabase (Project Settings > API).
// Os dois são PÚBLICOS por natureza: pode deixá-los aqui. A chave da IA do Claude NÃO vai aqui (fica na Vercel).
window.APP_CONFIG = {
  SUPABASE_URL: 'https://mswkffzutybokwqnrtrl.supabase.co',        // ex.: https://abcdefgh.supabase.co
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1zd2tmZnp1dHlib2t3cW5ydHJsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE4MjcyNDksImV4cCI6MjEwNzQwMzI0OX0.4M_G1dNmt0nI_wNxEPy1yf1Wbp1TR8oss-XXFbLQ-jw',   // chave "anon public"
  ADMIN_EMAIL: 'contato.energystudio@gmail.com'
};
