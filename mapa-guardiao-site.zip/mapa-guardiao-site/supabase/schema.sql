-- Mapa do Guardião · banco de dados (Supabase). Cole este arquivo inteiro em SQL Editor > New query > Run.
-- Administrador: contato.energystudio@gmail.com (troque nas 3 políticas "admin" abaixo, se mudar).

create table if not exists public.perfis (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  nome text,
  nascimento date,
  hora text,
  uf text,
  cidade text,
  lat double precision,
  lon double precision,
  tz double precision,
  dst boolean default false,
  objetivo text,
  aceite_lgpd_em timestamptz,
  created_at timestamptz default now()
);

create table if not exists public.mapas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  respostas jsonb,
  scores jsonb,
  resultado jsonb,
  guardiao text,
  ferida text,
  potencial text,
  created_at timestamptz default now()
);

create table if not exists public.geracoes (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  fase text not null,
  created_at timestamptz default now()
);

alter table public.perfis enable row level security;
alter table public.mapas enable row level security;
alter table public.geracoes enable row level security;

-- cada pessoa vê e edita só o que é dela
create policy "perfil: próprio" on public.perfis for select using (auth.uid() = id);
create policy "perfil: inserir próprio" on public.perfis for insert with check (auth.uid() = id);
create policy "perfil: atualizar próprio" on public.perfis for update using (auth.uid() = id);
create policy "mapas: próprio" on public.mapas for select using (auth.uid() = user_id);
create policy "mapas: inserir próprio" on public.mapas for insert with check (auth.uid() = user_id);

-- o administrador vê tudo
create policy "perfil: admin" on public.perfis for select using ((auth.jwt() ->> 'email') = 'contato.energystudio@gmail.com');
create policy "mapas: admin" on public.mapas for select using ((auth.jwt() ->> 'email') = 'contato.energystudio@gmail.com');
create policy "geracoes: admin" on public.geracoes for select using ((auth.jwt() ->> 'email') = 'contato.energystudio@gmail.com');
-- (geracoes só é escrita pelo servidor, com a chave de serviço; ninguém mais lê)

-- todo cadastro novo cria uma linha em perfis (assim você vê quem se cadastrou, mesmo sem terminar o teste)
create or replace function public.novo_usuario() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.perfis (id, email) values (new.id, new.email) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists ao_criar_usuario on auth.users;
create trigger ao_criar_usuario after insert on auth.users for each row execute function public.novo_usuario();
-- cadastros que já existirem antes deste script
insert into public.perfis (id, email) select id, email from auth.users on conflict (id) do nothing;
