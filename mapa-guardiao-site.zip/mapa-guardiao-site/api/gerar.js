// Função serverless (Vercel). Recebe os dados do teste, confere o login, chama a IA do Claude
// com a SUA chave (que só existe aqui, no servidor) e devolve o texto.
const { buildPrompt } = require('./_prompt.js');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'contato.energystudio@gmail.com').toLowerCase();
const MAX_MAPAS = parseInt(process.env.MAX_MAPAS || '3', 10); // mapas por pessoa (o admin não tem limite)

const sbHeaders = key => ({ apikey: key, Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' });

async function userFromToken(token) {
  const r = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: { apikey: SUPABASE_ANON_KEY, Authorization: 'Bearer ' + token } });
  if (!r.ok) return null;
  const u = await r.json();
  return u && u.id ? u : null;
}
async function countGeracoes(userId, fase, desdeISO) {
  let url = `${SUPABASE_URL}/rest/v1/ai_requests?select=id&user_id=eq.${userId}&fase=eq.${fase}`;
  if (desdeISO) url += `&created_at=gte.${encodeURIComponent(desdeISO)}`;
  const r = await fetch(url, { headers: { ...sbHeaders(SUPABASE_SERVICE_KEY), Prefer: 'count=exact', Range: '0-0' } });
  const cr = r.headers.get('content-range') || '*/0';
  return parseInt(cr.split('/')[1], 10) || 0;
}
async function logGeracao(userId, fase) {
  await fetch(`${SUPABASE_URL}/rest/v1/ai_requests`, { method: 'POST', headers: { ...sbHeaders(SUPABASE_SERVICE_KEY), Prefer: 'return=minimal' }, body: JSON.stringify({ user_id: userId, fase }) });
}
function parseJSON(text) {
  const a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('sem JSON');
  return JSON.parse(text.slice(a, b + 1));
}
async function chamarClaude(prompt) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: 5000, messages: [{ role: 'user', content: prompt }] })
  });
  const j = await r.json();
  if (!r.ok) { const e = new Error((j.error && j.error.message) || 'erro da IA'); e.status = r.status; throw e; }
  return (j.content || []).map(c => c.text || '').join('');
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ erro: 'metodo' });
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !SUPABASE_SERVICE_KEY || !ANTHROPIC_API_KEY) return res.status(500).json({ erro: 'configuracao', detalhe: 'Faltam variáveis de ambiente no servidor.' });
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const user = token ? await userFromToken(token) : null;
    if (!user) return res.status(401).json({ erro: 'login' });
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const { fase, teste, dossier } = body;
    if (!['a', 'b', 'c', 'd', 'e'].includes(fase) || typeof teste !== 'object' || typeof dossier !== 'object' || !teste || !dossier) return res.status(400).json({ erro: 'dados' });
    if (JSON.stringify(teste).length > 12000 || JSON.stringify(dossier).length > 30000) return res.status(413).json({ erro: 'grande' });

    const isAdmin = (user.email || '').toLowerCase() === ADMIN_EMAIL;
    if (!isAdmin) {
      const dia = new Date(Date.now() - 24 * 3600e3).toISOString();
      if (fase === 'a') {
        if ((await countGeracoes(user.id, 'a')) >= MAX_MAPAS) return res.status(429).json({ erro: 'limite', detalhe: `Você já gerou ${MAX_MAPAS} mapas.` });
      } else {
        if ((await countGeracoes(user.id, fase, dia)) >= MAX_MAPAS) return res.status(429).json({ erro: 'limite', detalhe: 'Limite diário atingido.' });
      }
    }
    await logGeracao(user.id, fase);

    const prompt = buildPrompt(fase, teste, dossier);
    let out;
    for (let i = 0; i < 2 && !out; i++) { // 1 nova tentativa se o JSON vier quebrado
      const texto = await chamarClaude(prompt);
      try { out = parseJSON(texto); } catch (e) { if (i === 1) throw e; }
    }
    return res.status(200).json({ ok: true, parte: out });
  } catch (e) {
    console.error('gerar', e && e.message);
    const st = e && e.status === 429 ? 429 : 500;
    return res.status(st).json({ erro: 'ia', detalhe: 'Não foi possível gerar agora. Tente de novo em instantes.' });
  }
};
